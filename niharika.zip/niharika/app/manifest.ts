import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest {
  return { name: "নীহারিকা", short_name: "নীহারিকা", start_url: "/", display: "standalone", background_color: "#0b1020", theme_color: "#0b1020", icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }] };
}
